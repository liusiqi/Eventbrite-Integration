﻿the initial api call returns two objects, the 1st is the pagination 

screen shot: http://screencast.com/t/YyoKAnE6xZ

the 2nd object is the events details. 

Validating return events are only based on the event status of "alive", which is check while looping through received list.

